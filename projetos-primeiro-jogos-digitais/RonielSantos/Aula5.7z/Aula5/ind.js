// Função para calcular o custo total da viagem
function calcularCustoViagem() {
    // Solicita o número de passageiros adultos e crianças
    let adultos = parseInt(prompt("Digite o número de passageiros adultos:"));
    let criancas = parseInt(prompt("Digite o número de passageiros crianças:"));
    
    // Solicita o destino da viagem
    let destino = prompt("Digite o destino (Norte, Sul, Ásia, Europa, África):").toLowerCase();
    
    // Solicita a classe do voo
    let classe = prompt("Digite a classe do voo (Econômica ou Executiva):").toLowerCase();
    
    // Declaração de variáveis para armazenar os preços
    let precoAdulto, precoCrianca;
    
    // Calcula o custo com base no destino e na classe escolhida
    switch (destino) {
        case "norte":
            if (classe === "econômica") {
                precoAdulto = 1200;
                precoCrianca = 900;
            } else if (classe === "executiva") {
                precoAdulto = 2500 * 1.20; // 20% de aumento
                precoCrianca = 2200 * 1.10; // 10% de aumento
            }
            break;
        case "sul":
            precoAdulto = 2200;
            precoCrianca = 2200;
            break;
        case "ásia":
            if (classe === "econômica") {
                precoAdulto = 3600;
                precoCrianca = 3600;
            } else if (classe === "executiva") {
                precoAdulto = 5000;
                precoCrianca = 5000;
            }
            break;
        case "europa":
            if (classe === "econômica") {
                precoAdulto = 5800;
                precoCrianca = 5800;
            } else if (classe === "executiva") {
                precoAdulto = 7300;
                precoCrianca = 7300;
            }
            break;
        case "áfrica":
            if (classe === "econômica") {
                precoAdulto = 2200;
                precoCrianca = 2200;
            } else if (classe === "executiva") {
                precoAdulto = 3900;
                precoCrianca = 3900;
            }
            break;
        default:
            console.log("Destino inválido.");
            return;
    }
    
    // Calcula o custo total
    let custoTotal = (adultos * precoAdulto) + (criancas * precoCrianca);
    
    // Exibe o custo total e informações sobre a viagem
    console.log(`Quantidade de passageiros adultos: ${adultos}`);
    console.log(`Quantidade de passageiros crianças: ${criancas}`);
    console.log(`Classe do voo: ${classe}`);
    console.log(`Destino: ${destino}`);
    console.log(`Custo total da viagem: R$ ${custoTotal.toFixed(2)}`);
}

// Executa a função para calcular o custo da viagem
calcularCustoViagem();
